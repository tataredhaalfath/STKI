<?php
$host='localhost';
$user='id14976533_dbstbi1';
$pass='wI4q5A!9Y_%Ovwqu';
$database='id14976533_dbstbi';

$conn = mysqli_connect($host,$user,$pass,$database);
?>